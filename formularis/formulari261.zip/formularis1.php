<?php
    $nom = $_GET["nombre"];
    echo "<p>Benvingut $nom</p>";
?>